# Prowler Bracken
Gives the bracken the prowler sound effects from Into the Spiderverse
Only changes audio, but may compete with other mods that change bracken audio

## How to use this mod
1. Install and load BepInEx, if you haven't already
2. Move the "ProwlerBracken.dll" file into your plugins folder at ...\Steam\steamapps\common\Lethal Company\BepInEx\plugins

## Made by : Danninx
Message me if you find any errors in the mod, or if you have any recommendations/advice
(You can find me in the LC Modding Discord, although I'm not very active)