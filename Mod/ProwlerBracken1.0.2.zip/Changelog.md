# Changelog

## 1.0.2
- Bracken will now make random Prowler sounds

## 1.0.1
- Fixed mod listing